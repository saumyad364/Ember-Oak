
/* ============================================================
   STATE (in-memory only — this is a front-end demo; wire up
   a real backend/DB for persistence in production)
   ============================================================ */
let menu = [
  {id:1, name:'Single-Origin Pour Over', cat:'Coffee', price:180, desc:'Ethiopian Yirgacheffe — bright, floral, tea-like.', img:'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=700&q=85'},
  {id:2, name:'Dark Roast Espresso', cat:'Coffee', price:120, desc:'Double shot, syrupy body, dark chocolate finish.', img:'https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?auto=format&fit=crop&w=700&q=85'},
  {id:3, name:'Oak-Smoked Cold Brew', cat:'Coffee', price:190, desc:'Our signature — 18hr steep over oak chips.', img:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=700&q=85'},
  {id:4, name:'Cortado', cat:'Coffee', price:150, desc:'Equal parts espresso and warm milk.', img:'https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=700&q=85'},
  {id:5, name:'Hojicha Latte', cat:'Tea', price:170, desc:'Roasted green tea, steamed milk, gentle smoke.', img:'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=700&q=85'},
  {id:6, name:'Chamomile Ember Blend', cat:'Tea', price:140, desc:'House chamomile with orange peel and clove.', img:'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=700&q=85'},
  {id:7, name:'Brown Butter Croissant', cat:'Pastries', price:110, desc:'Laminated daily, brown-butter glaze.', img:'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=700&q=85'},
  {id:8, name:'Cardamom Sticky Bun', cat:'Pastries', price:130, desc:'Slow-proofed, cardamom-brown sugar swirl.', img:'https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=700&q=85'},
  {id:9, name:'Maple Oat Flat White', cat:'Specials', price:200, desc:'Oat milk, maple, ristretto shots — seasonal.', img:'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=700&q=85'},
  {id:10, name:'Vanilla Cappuccino', cat:'Coffee', price:170, desc:'Velvety espresso, steamed milk and vanilla foam.', img:'https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=700&q=85'},
  {id:11, name:'Iced Caramel Latte', cat:'Coffee', price:190, desc:'Chilled espresso, creamy milk and caramel.', img:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=700&q=85'},
  {id:12, name:'Blueberry Cheesecake', cat:'Pastries', price:180, desc:'Creamy cheesecake with a bright blueberry topping.', img:'https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=700&q=85'},
  {id:13, name:'Chocolate Brownie', cat:'Pastries', price:120, desc:'Rich, fudgy chocolate brownie with a soft centre.', img:'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=700&q=85'},
  {id:14, name:'Avocado Toast', cat:'Specials', price:210, desc:'Sourdough toast, smashed avocado and cafe seasoning.', img:'https://images.unsplash.com/photo-1541519227354-08fa5d50c44d?auto=format&fit=crop&w=700&q=85'},

  {id:15, name:'Grilled Veg & Cheese Sandwich', cat:'Food', price:220, desc:'Char-grilled seasonal vegetables, melted cheese, sourdough.', img:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=700&q=85'},
  {id:16, name:'Peri-Peri Chicken Wrap', cat:'Food', price:250, desc:'Grilled chicken, peri-peri sauce, crunchy slaw, soft tortilla.', img:'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=700&q=85'},
  {id:17, name:'Roastery Club Sandwich', cat:'Food', price:260, desc:'Triple-decker with chicken, egg, cheese and house mayo.', img:'https://images.unsplash.com/photo-1567234669003-dce7a7a88821?auto=format&fit=crop&w=700&q=85'},
  {id:18, name:'Mediterranean Falafel Bowl', cat:'Food', price:280, desc:'Crisp falafel, hummus, pita, fresh salad and tahini drizzle.', img:'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=700&q=85'},
  {id:19, name:'Creamy Tomato Basil Pasta', cat:'Food', price:290, desc:'Penne in a slow-simmered tomato-basil cream sauce, parmesan.', img:'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?auto=format&fit=crop&w=700&q=85'},
  {id:20, name:'Classic Cheese Burger', cat:'Food', price:270, desc:'Grilled patty, melted cheddar, house sauce, brioche bun, fries on the side.', img:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=85'},
  {id:21, name:'Farmhouse Garden Salad', cat:'Food', price:200, desc:'Mixed greens, cherry tomato, feta, walnuts, honey-mustard dressing.', img:'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=700&q=85'},
  {id:22, name:'Roasted Tomato Basil Soup', cat:'Food', price:170, desc:'Slow-roasted tomatoes, fresh basil, served with garlic toast.', img:'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=85'},

  {id:23, name:'Creamy Alfredo Pasta', cat:'Pasta', price:290, desc:'Penne tossed in creamy parmesan Alfredo sauce with herbs.', img:'https://images.unsplash.com/photo-1555949258-eb67b1ef0ceb?auto=format&fit=crop&w=700&q=85'},
  {id:24, name:'Arrabbiata Pasta', cat:'Pasta', price:260, desc:'Penne in a spicy tomato-garlic sauce finished with basil.', img:'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=85'},
  {id:25, name:'Pesto Penne Pasta', cat:'Pasta', price:300, desc:'Penne with basil pesto, parmesan, cherry tomatoes and toasted seeds.', img:'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=85'},
  {id:26, name:'Pink Sauce Pasta', cat:'Pasta', price:310, desc:'A creamy tomato and cheese sauce with herbs and parmesan.', img:'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?auto=format&fit=crop&w=700&q=85'},

  {id:27, name:'Margherita Pizza', cat:'Pizza', price:280, desc:'Classic tomato, mozzarella, basil and olive oil on a crisp crust.', img:'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=700&q=85'},
  {id:28, name:'Farmhouse Veg Pizza', cat:'Pizza', price:340, desc:'Bell peppers, onion, mushrooms, olives and mozzarella.', img:'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=700&q=85'},
  {id:29, name:'Paneer Tikka Pizza', cat:'Pizza', price:360, desc:'Tandoori paneer, onion, capsicum and smoky tikka sauce.', img:'https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=700&q=85'},
  {id:30, name:'BBQ Chicken Pizza', cat:'Pizza', price:390, desc:'BBQ chicken, caramelized onion, mozzarella and smoky BBQ drizzle.', img:'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=700&q=85'},

  {id:31, name:'Classic Veg Burger', cat:'Burgers', price:220, desc:'Crispy veggie patty, lettuce, tomato, cheese and house sauce.', img:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=85'},
  {id:32, name:'Crispy Chicken Burger', cat:'Burgers', price:290, desc:'Crunchy chicken fillet, lettuce, cheese and creamy burger sauce.', img:'https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=700&q=85'},
  {id:33, name:'Paneer Crunch Burger', cat:'Burgers', price:260, desc:'Crispy paneer patty, jalapeño, lettuce and spicy mayo.', img:'https://images.unsplash.com/photo-1550317138-10000687a72b?auto=format&fit=crop&w=700&q=85'},

  {id:34, name:'Classic French Fries', cat:'Fries', price:140, desc:'Golden, crisp fries with a light seasoning.', img:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=85'},
  {id:35, name:'Peri-Peri French Fries', cat:'Fries', price:160, desc:'Crispy fries tossed in smoky, spicy peri-peri seasoning.', img:'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&w=700&q=85'},
  {id:36, name:'Cheesy Loaded Fries', cat:'Fries', price:220, desc:'Crispy fries topped with cheese sauce, jalapeños and herbs.', img:'https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=700&q=85'},

  {id:37, name:'Steamed Veg Momos', cat:'Momos', price:180, desc:'Soft dumplings filled with seasoned vegetables, served with spicy dip.', img:'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?auto=format&fit=crop&w=700&q=85'},
  {id:38, name:'Fried Chicken Momos', cat:'Momos', price:240, desc:'Crispy fried dumplings with juicy chicken filling and chilli dip.', img:'https://images.unsplash.com/photo-1626197031507-c17099753214?auto=format&fit=crop&w=700&q=85'},
  {id:39, name:'Tandoori Paneer Momos', cat:'Momos', price:230, desc:'Paneer momos coated in smoky tandoori masala and grilled.', img:'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=700&q=85'},

  {id:40, name:'Grilled Cheese Sandwich', cat:'Sandwiches', price:190, desc:'Golden grilled sourdough with melted cheese and herbs.', img:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=700&q=85'},
  {id:41, name:'Paneer Tikka Sandwich', cat:'Sandwiches', price:240, desc:'Spiced paneer tikka, peppers, onion, cheese and mint mayo.', img:'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&w=700&q=85'},
  {id:42, name:'Crispy Chicken Sandwich', cat:'Sandwiches', price:260, desc:'Crispy chicken, lettuce, tomato, cheese and creamy house mayo.', img:'https://images.unsplash.com/photo-1567234669003-dce7a7a88821?auto=format&fit=crop&w=700&q=85'}
];

const FAST_FOOD_MENU = [
  {id:23, name:'Creamy Alfredo Pasta', cat:'Pasta', price:290, desc:'Penne tossed in creamy parmesan Alfredo sauce with herbs.', img:'https://images.unsplash.com/photo-1555949258-eb67b1ef0ceb?auto=format&fit=crop&w=700&q=85'},
  {id:24, name:'Arrabbiata Pasta', cat:'Pasta', price:260, desc:'Penne in a spicy tomato-garlic sauce finished with basil.', img:'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=85'},
  {id:25, name:'Pesto Penne Pasta', cat:'Pasta', price:300, desc:'Penne with basil pesto, parmesan, cherry tomatoes and toasted seeds.', img:'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=85'},
  {id:26, name:'Pink Sauce Pasta', cat:'Pasta', price:310, desc:'A creamy tomato and cheese sauce with herbs and parmesan.', img:'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?auto=format&fit=crop&w=700&q=85'},
  {id:27, name:'Margherita Pizza', cat:'Pizza', price:280, desc:'Classic tomato, mozzarella, basil and olive oil on a crisp crust.', img:'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=700&q=85'},
  {id:28, name:'Farmhouse Veg Pizza', cat:'Pizza', price:340, desc:'Bell peppers, onion, mushrooms, olives and mozzarella.', img:'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=700&q=85'},
  {id:29, name:'Paneer Tikka Pizza', cat:'Pizza', price:360, desc:'Tandoori paneer, onion, capsicum and smoky tikka sauce.', img:'https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=700&q=85'},
  {id:30, name:'BBQ Chicken Pizza', cat:'Pizza', price:390, desc:'BBQ chicken, caramelized onion, mozzarella and smoky BBQ drizzle.', img:'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=700&q=85'},
  {id:31, name:'Classic Veg Burger', cat:'Burgers', price:220, desc:'Crispy veggie patty, lettuce, tomato, cheese and house sauce.', img:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=85'},
  {id:32, name:'Crispy Chicken Burger', cat:'Burgers', price:290, desc:'Crunchy chicken fillet, lettuce, cheese and creamy burger sauce.', img:'https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=700&q=85'},
  {id:33, name:'Paneer Crunch Burger', cat:'Burgers', price:260, desc:'Crispy paneer patty, jalapeño, lettuce and spicy mayo.', img:'https://images.unsplash.com/photo-1550317138-10000687a72b?auto=format&fit=crop&w=700&q=85'},
  {id:34, name:'Classic French Fries', cat:'Fries', price:140, desc:'Golden, crisp fries with a light seasoning.', img:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=85'},
  {id:35, name:'Peri-Peri French Fries', cat:'Fries', price:160, desc:'Crispy fries tossed in smoky, spicy peri-peri seasoning.', img:'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&w=700&q=85'},
  {id:36, name:'Cheesy Loaded Fries', cat:'Fries', price:220, desc:'Crispy fries topped with cheese sauce, jalapeños and herbs.', img:'https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=700&q=85'},
  {id:37, name:'Steamed Veg Momos', cat:'Momos', price:180, desc:'Soft dumplings filled with seasoned vegetables, served with spicy dip.', img:'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?auto=format&fit=crop&w=700&q=85'},
  {id:38, name:'Fried Chicken Momos', cat:'Momos', price:240, desc:'Crispy fried dumplings with juicy chicken filling and chilli dip.', img:'https://images.unsplash.com/photo-1626197031507-c17099753214?auto=format&fit=crop&w=700&q=85'},
  {id:39, name:'Tandoori Paneer Momos', cat:'Momos', price:230, desc:'Paneer momos coated in smoky tandoori masala and grilled.', img:'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=700&q=85'},
  {id:40, name:'Grilled Cheese Sandwich', cat:'Sandwiches', price:190, desc:'Golden grilled sourdough with melted cheese and herbs.', img:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=700&q=85'},
  {id:41, name:'Paneer Tikka Sandwich', cat:'Sandwiches', price:240, desc:'Spiced paneer tikka, peppers, onion, cheese and mint mayo.', img:'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&w=700&q=85'},
  {id:42, name:'Crispy Chicken Sandwich', cat:'Sandwiches', price:260, desc:'Crispy chicken, lettuce, tomato, cheese and creamy house mayo.', img:'https://images.unsplash.com/photo-1567234669003-dce7a7a88821?auto=format&fit=crop&w=700&q=85'}
];

let customers = [
  {id:1, username:'ja1n2@', name:'Jane Doe', email:'jane@example.com', password:'coffee123', points:210,
    orders:[{id:1001, item:'Oak-Smoked Cold Brew', price:190, status:'Ready'}]}
];

let orders = [
  {id:1001, customerId:1, customerName:'Jane Doe', item:'Oak-Smoked Cold Brew', price:190, status:'Ready'}
];

const ADMIN_CREDS = {username:'admin', password:'roast2026'};
let orderSeq = 1002;

let session = {role:null, customerId:null}; // role: 'customer' | 'admin' | null
let authRole = 'customer';
let authMode = 'login';
let currentMood = null;
let checkoutCart = [];        // [{name, price, qty, cat}]
let checkoutDiscount = 0;
let checkoutOfferCode = '';
let checkoutSource = null;    // 'cart' | 'event' | null — where checkout was launched from

let cart = []; // {key, name, price, qty, cat, img}

let tableBookings = [];
const TABLE_SIZES = [2,4,6,10,12];
let selectedTableSize = null;

const DRINK_BASES  = [{id:'espresso', name:'Espresso', price:0}, {id:'coldbrew', name:'Cold Brew', price:20}, {id:'greentea', name:'Green Tea', price:0}, {id:'hotchoc', name:'Hot Chocolate', price:30}];
const DRINK_MILKS  = [{id:'whole', name:'Whole Milk', price:0}, {id:'oat', name:'Oat Milk', price:20}, {id:'almond', name:'Almond Milk', price:20}, {id:'none', name:'No Milk', price:0}];
const DRINK_SIZES  = [{id:'reg', name:'Regular', price:0}, {id:'lrg', name:'Large', price:30}];
const DRINK_SYRUPS = [{id:'none', name:'None', price:0}, {id:'vanilla', name:'Vanilla', price:15}, {id:'caramel', name:'Caramel', price:15}, {id:'hazelnut', name:'Hazelnut', price:15}];
const DRINK_EXTRAS = [{id:'shot', name:'Extra shot', price:25}, {id:'cream', name:'Whipped cream', price:20}];
let builderChoice = {base:'espresso', milk:'whole', size:'reg', syrup:'none', extras:[]};

let adminTab = 'orders';
let menuFilter = 'All';
const STATUS_FLOW = ['Ordering','Brewing','Ready','Picked'];
const STATUS_LABEL = {Ordering:'Ordering', Brewing:'Brewing', Ready:'Ready', Picked:'Picked Up'};

/* ============================================================
   PERSISTENCE
   Tries the Claude.ai artifact's window.storage key-value API
   first (works when this page is opened inside a Claude.ai
   artifact preview). When that's not available — e.g. this file
   is downloaded and opened directly in a browser (file:// or a
   regular web server) — it falls back to the browser's own
   localStorage, so accounts/orders/cart/bookings are still
   remembered on that device between visits.
   ============================================================ */
function hasArtifactStorage(){ return typeof window.storage !== 'undefined' && !!window.storage; }
function hasLocalStorage(){
  try{ const k='__eo_test__'; localStorage.setItem(k,'1'); localStorage.removeItem(k); return true; }
  catch(e){ return false; }
}
const LS_PREFIX = 'emberoak:';
async function storageGet(key, shared, fallback){
  if(hasArtifactStorage()){
    try{
      const r = await window.storage.get(key, shared);
      if(r && r.value) return JSON.parse(r.value);
    }catch(e){ /* fall through to localStorage */ }
  }
  if(hasLocalStorage()){
    try{
      const raw = localStorage.getItem(LS_PREFIX+key);
      if(raw) return JSON.parse(raw);
    }catch(e){ /* ignore, use fallback */ }
  }
  return fallback;
}
async function storageSet(key, value, shared){
  if(hasArtifactStorage()){
    try{ await window.storage.set(key, JSON.stringify(value), shared); return; }catch(e){ /* fall through */ }
  }
  if(hasLocalStorage()){
    try{ localStorage.setItem(LS_PREFIX+key, JSON.stringify(value)); }catch(e){ /* ignore, e.g. storage full/private mode */ }
  }
}
function saveCustomers(){ storageSet('customers', customers, true); }
function saveOrders(){ storageSet('orders', orders, true); }
function saveMenu(){ storageSet('menu', menu, true); }
function saveTableBookings(){ storageSet('tableBookings', tableBookings, true); }
function saveSession(){ storageSet('session', session, false); }
function saveCart(){ if(session.customerId) storageSet('cart:'+session.customerId, cart, false); }
function saveLastLoginId(loginId){ if(loginId) storageSet('lastLoginId', loginId, false); }
function ensureFastFoodMenu(){
  const existingIds = new Set(menu.map(m=>m.id));
  const missing = FAST_FOOD_MENU.filter(m=>!existingIds.has(m.id));
  if(missing.length){ menu = menu.concat(missing); saveMenu(); }
  customers = customers.map(c=>({...c, username:c.username || c.email.split('@')[0].replace(/[^a-z0-9_]/gi,'').toLowerCase()}));
  saveCustomers();
}

async function initApp(){
  const savedCustomers = await storageGet('customers', true, null);
  if(savedCustomers && savedCustomers.length) customers = savedCustomers;
  const savedOrders = await storageGet('orders', true, null);
  if(savedOrders) orders = savedOrders;
  const savedMenu = await storageGet('menu', true, null);
  if(savedMenu && savedMenu.length) menu = savedMenu;
  ensureFastFoodMenu();
  const savedTables = await storageGet('tableBookings', true, null);
  if(savedTables) tableBookings = savedTables;

  orderSeq = orders.reduce((m,o)=>Math.max(m, o.id+1), orderSeq);

  const savedLastLoginId = await storageGet('lastLoginId', false, null);
  if(savedLastLoginId){
    const loginInput = document.getElementById('loginId');
    if(loginInput) loginInput.value = savedLastLoginId;
  }

  const savedSession = await storageGet('session', false, null);
  if(savedSession && savedSession.role){
    if(savedSession.role==='admin'){
      session = savedSession;
    } else if(savedSession.role==='customer' && customers.find(c=>c.id===savedSession.customerId)){
      session = savedSession;
    }
  }
  if(session.role==='customer'){
    const savedCart = await storageGet('cart:'+session.customerId, false, null);
    if(savedCart) cart = savedCart;
  }

  updateNavForSession();
  renderCartBadge();
  if(session.role==='customer') go('customer');
  else if(session.role==='admin') go('admin');
  else go('home');
}

/* ============================================================
   NAVIGATION
   ============================================================ */
function go(view){
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.getElementById('view-'+view).classList.add('active');
  window.scrollTo({top:0, behavior:'smooth'});
  if(view==='menu') renderMenu();
  if(view==='checkout') renderCheckout();
  if(view==='payment') renderPaymentPage();
  if(view==='customer') renderCustomerDash();
  if(view==='admin') renderAdminDash();
  if(view==='cart') renderCart();
  if(view==='builder') renderBuilder();
  if(view==='tables') renderTables();
  document.querySelectorAll('.nav-links .linklike').forEach(b=>b.classList.remove('active'));
  const navBtn = document.getElementById('navlink-'+view);
  if(navBtn) navBtn.classList.add('active');
}

function updateThemeIcon(){
  const icon = document.getElementById('themeIcon');
  const btn = document.getElementById('themeToggle');
  if(!icon || !btn) return;
  const isDark = document.body.dataset.theme === 'dark';
  // Half-moon/crescent logo is used for dark mode.
  icon.textContent = isDark ? '◐' : '☾';
  btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
  btn.setAttribute('aria-label', btn.title);
}
function toggleTheme(){
  const b = document.body;
  b.dataset.theme = b.dataset.theme==='light' ? 'dark' : 'light';
  updateThemeIcon();
}

function updateNavForSession(){
  const link = document.getElementById('navDashLink');
  if(session.role==='customer'){
    const c = customers.find(x=>x.id===session.customerId);
    link.textContent = c ? (c.username || c.name.split(' ')[0])+"'s account" : 'Account';
    link.onclick = ()=>go('customer');
  } else if(session.role==='admin'){
    link.textContent = 'Admin console';
    link.onclick = ()=>go('admin');
  } else {
    link.textContent = 'Login';
    link.onclick = ()=>go('login');
  }
}

function logout(){
  session = {role:null, customerId:null};
  saveSession();
  cart = [];
  renderCartBadge();
  updateNavForSession();
  go('home');
}

/* ============================================================
   MENU PAGE
   ============================================================ */
function renderMenuFilters(){
  const cats = ['All', ...new Set(menu.map(m=>m.cat))];
  const el = document.getElementById('menuFilters');
  el.innerHTML = cats.map(c=>`<button class="filter-btn ${c===menuFilter?'active':''}" onclick="setMenuFilter('${c}')">${c}</button>`).join('');
}
function setMenuFilter(c){ menuFilter=c; renderMenu(); }

function renderMenu(){
  renderMenuFilters();
  const list = menuFilter==='All' ? menu : menu.filter(m=>m.cat===menuFilter);
  const grid = document.getElementById('menuGrid');
  grid.innerHTML = list.map(m=>`
    <div class="card menu-card">
      <img src="${m.img}" alt="${m.name}">
      <span class="tag">${m.cat}</span>
      <div class="row"><h3 style="font-size:1.05rem;">${m.name}</h3><span class="price">₹${m.price}</span></div>
      <p>${m.desc}</p>
      <div class="card-actions">
        <button class="btn btn-primary btn-sm" onclick="addToCart(${m.id}, event)">Add to cart</button>
      </div>
    </div>`).join('') || '<p class="empty">Nothing in this category right now.</p>';
}

/* ============================================================
   AUTH
   ============================================================ */
function setAuthRole(role){
  authRole = role;
  document.getElementById('tabCustomer').classList.toggle('active', role==='customer');
  document.getElementById('tabAdmin').classList.toggle('active', role==='admin');
  document.getElementById('customerAuth').style.display = role==='customer' ? 'block':'none';
  document.getElementById('adminAuth').style.display = role==='admin' ? 'block':'none';
}
function setAuthMode(mode){
  authMode = mode;
  document.getElementById('tabLogin').classList.toggle('active', mode==='login');
  document.getElementById('tabSignup').classList.toggle('active', mode==='signup');
  document.getElementById('loginForm').style.display = mode==='login' ? 'block':'none';
  document.getElementById('signupForm').style.display = mode==='signup' ? 'block':'none';
  document.getElementById('authMsg').innerHTML = '';
}

function surpriseUsername(){
  const adjectives = ['Cozy','Foamy','Bold','Nutty','Toasty','Velvet','Smoky','Sunny','Frothy','Dreamy'];
  const nouns = ['Latte','Bean','Roaster','Brew','Espresso','Mocha','Barista','Cinnamon','Oat','Cup'];
  const num = Math.floor(Math.random()*90)+10;
  const name = adjectives[Math.floor(Math.random()*adjectives.length)] + nouns[Math.floor(Math.random()*nouns.length)] + num;
  const input = document.getElementById('suUsername');
  input.value = name;
  funBurst();
}
function validUsername(value){
  // Any name works now — just needs at least 2 characters, no @ required.
  return value.trim().length >= 2;
}
function validEmail(value){
  // Must contain the @ symbol exactly once, with something on both sides.
  const ats = (value.match(/@/g)||[]).length;
  return ats === 1 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}
function sanitizeLoginId(input){
  input.value = input.value.replace(/\s/g,'');
}
function handleCustomerLogin(e){
  e.preventDefault();
  const input = document.getElementById('loginId');
  sanitizeLoginId(input);
  const loginId = input.value.trim().toLowerCase();
  const pass = document.getElementById('loginPassword').value;
  const msg = document.getElementById('authMsg');
  if(!validUsername(loginId)){
    msg.innerHTML = '<div class="msg msg-error">Please enter your username.</div>';
    return false;
  }
  const c = customers.find(x => (x.username && x.username.toLowerCase()===loginId) && x.password===pass);
  if(!c){
    msg.innerHTML = '<div class="msg msg-error">No matching account. Check your username and password, or create an account.</div>';
    return false;
  }
  session = {role:'customer', customerId:c.id};
  saveSession();
  saveLastLoginId(c.username);
  storageGet('cart:'+c.id, false, []).then(saved=>{ cart = saved || []; renderCartBadge(); });
  msg.innerHTML = '';
  updateNavForSession();
  funBurst();
  go('customer');
  return false;
}

function handleCustomerSignup(e){
  e.preventDefault();
  const usernameInput = document.getElementById('suUsername');
  sanitizeLoginId(usernameInput);
  const username = usernameInput.value.trim().toLowerCase();
  const name = document.getElementById('suName').value.trim();
  const email = document.getElementById('suEmail').value.trim().toLowerCase();
  const pass = document.getElementById('suPassword').value;
  const msg = document.getElementById('authMsg');
  if(!validUsername(username)){
    msg.innerHTML = '<div class="msg msg-error">Please choose a username (at least 2 characters).</div>';
    return false;
  }
  if(!validEmail(email)){
    msg.innerHTML = '<div class="msg msg-error">Please enter a valid email address with exactly one @ symbol.</div>';
    return false;
  }
  if(customers.some(x=>x.email.toLowerCase()===email)){
    msg.innerHTML = '<div class="msg msg-error">An account with that email already exists.</div>';
    return false;
  }
  if(customers.some(x=>(x.username||'').toLowerCase()===username)){
    msg.innerHTML = '<div class="msg msg-error">That username is already taken. Choose another one.</div>';
    return false;
  }
  const c = {id:Date.now(), username, name, email, password:pass, points:0, orders:[]};
  customers.push(c);
  saveCustomers();
  session = {role:'customer', customerId:c.id};
  saveSession();
  saveLastLoginId(username);
  msg.innerHTML = '';
  updateNavForSession();
  funBurst();
  go('customer');
  return false;
}

function handleAdminLogin(e){
  e.preventDefault();
  const u = document.getElementById('adminUser').value.trim();
  const p = document.getElementById('adminPass').value;
  const msg = document.getElementById('adminMsg');
  if(u===ADMIN_CREDS.username && p===ADMIN_CREDS.password){
    session = {role:'admin', customerId:null};
    saveSession();
    msg.innerHTML = '';
    updateNavForSession();
    go('admin');
  } else {
    msg.innerHTML = '<div class="msg msg-error">Incorrect admin credentials.</div>';
  }
  return false;
}

/* ============================================================
   CART
   ============================================================ */
function cartCount(){ return cart.reduce((s,i)=>s+i.qty,0); }
function cartSubtotal(){ return cart.reduce((s,i)=>s+i.qty*i.price,0); }

function renderCartBadge(){
  const b = document.getElementById('cartBadge');
  const n = cartCount();
  b.textContent = n;
  b.classList.toggle('show', n>0);
}

/* ============================================================
   FUN MODE HELPERS — confetti + video sound toggle
   ============================================================ */
function funBurst(x, y){
  if(typeof confetti !== 'function') return;
  try{
    confetti({
      particleCount: 70,
      spread: 65,
      startVelocity: 32,
      origin: { x: x!=null ? x : 0.5, y: y!=null ? y : 0.6 },
      colors: ['#a94720','#e16a32','#d6a72c','#66734f','#fff7e8'],
      scalar: 0.9
    });
  }catch(e){}
}
function funBurstFromEvent(evt){
  if(!evt) { funBurst(); return; }
  const x = evt.clientX / window.innerWidth;
  const y = evt.clientY / window.innerHeight;
  funBurst(x, y);
}
function toggleTileSound(btn){
  const video = btn.parentElement.querySelector('video');
  if(!video) return;
  video.muted = !video.muted;
  btn.textContent = video.muted ? '🔇' : '🔊';
  if(!video.muted){ video.play().catch(()=>{}); }
}

function addToCart(menuId, evt){
  const item = menu.find(m=>m.id===menuId);
  if(!item) return;
  const existing = cart.find(i=>i.key==='menu-'+item.id);
  if(existing) existing.qty += 1;
  else cart.push({key:'menu-'+item.id, name:item.name, price:item.price, qty:1, cat:item.cat, img:item.img});
  saveCart();
  renderCartBadge();
  funBurstFromEvent(evt || window.event);
  if(document.getElementById('view-cart').classList.contains('active')) renderCart();
}

function changeCartQty(key, delta){
  const item = cart.find(i=>i.key===key);
  if(!item) return;
  item.qty += delta;
  if(item.qty<=0) cart = cart.filter(i=>i.key!==key);
  saveCart();
  renderCartBadge();
  renderCart();
}

function removeFromCart(key){
  cart = cart.filter(i=>i.key!==key);
  saveCart();
  renderCartBadge();
  renderCart();
}

function renderCart(){
  const body = document.getElementById('cartBody');
  if(!cart.length){
    body.innerHTML = '<p class="empty">Your cart is empty. <a href="#" onclick="go(\'menu\');return false;" style="color:var(--ember-2);">Browse the menu →</a></p>';
    return;
  }
  const rows = cart.map(i=>`
    <div class="cart-row">
      ${i.img ? `<img src="${i.img}" alt="${i.name}">` : ''}
      <div class="info">
        <div class="name">${i.name}</div>
        <div class="meta">₹${i.price} each</div>
      </div>
      <div class="qty-control">
        <button onclick="changeCartQty('${i.key}',-1)">−</button>
        <span>${i.qty}</span>
        <button onclick="changeCartQty('${i.key}',1)">+</button>
      </div>
      <div class="line-total">₹${i.price*i.qty}</div>
      <button class="cart-remove" onclick="removeFromCart('${i.key}')" title="Remove">✕</button>
    </div>`).join('');
  body.innerHTML = `
    <div class="card" style="padding:6px 22px;">${rows}</div>
    <div class="cart-summary" style="margin-top:20px;">
      <div class="summary-row summary-total"><span>Subtotal</span><strong>₹${cartSubtotal()}</strong></div>
      <button class="btn btn-primary" style="width:100%;margin-top:10px;" onclick="proceedToCartCheckout()">Proceed to checkout</button>
      <button class="btn btn-ghost" style="width:100%;margin-top:10px;" onclick="go('menu')">Add more items</button>
    </div>`;
}

function proceedToCartCheckout(){
  const c = currentCustomer();
  if(!c){ go('login'); return; }
  if(!cart.length) return;
  checkoutCart = cart.map(i=>({name:i.name, price:i.price, qty:i.qty, cat:i.cat}));
  checkoutSource = 'cart';
  checkoutDiscount = 0;
  checkoutOfferCode = '';
  go('checkout');
}

/* ============================================================
   EVENTS / OFFERS / CHECKOUT
   ============================================================ */
function copyOffer(code){
  if(navigator.clipboard){
    navigator.clipboard.writeText(code).catch(()=>{});
  }
  funBurst();
  alert('Offer code ' + code + ' copied! 🎉 Use it at checkout.');
}

function bookEvent(name, price){
  if(price === 0){
    funBurst();
    alert(name + ' reserved successfully! 🎉 See you at Ember & Oak.');
    return;
  }
  checkoutCart = [{name:name, price:price, qty:1, cat:'Event'}];
  checkoutSource = 'event';
  checkoutDiscount = 0;
  checkoutOfferCode = '';
  go('checkout');
}

function openCheckout(){
  const c = currentCustomer();
  if(!c){ go('login'); return; }
  const id = parseInt(document.getElementById('quickOrderItem').value);
  const item = menu.find(m=>m.id===id);
  if(!item) return;
  checkoutCart = [{name:item.name, price:item.price, qty:1, cat:item.cat}];
  checkoutSource = 'quick';
  checkoutDiscount = 0;
  checkoutOfferCode = '';
  go('checkout');
}

function checkoutSubtotal(){ return checkoutCart.reduce((s,i)=>s+i.price*i.qty,0); }

function renderCheckout(){
  if(!checkoutCart.length){
    go('menu');
    return;
  }
  document.getElementById('checkoutLines').innerHTML = checkoutCart.map(i=>`
    <div class="summary-row"><span>${i.name}${i.qty>1 ? ' × '+i.qty : ''}</span><strong>₹${i.price*i.qty}</strong></div>
  `).join('');
  document.getElementById('checkoutPrice').textContent = '₹'+checkoutSubtotal();
  updateCheckoutTotals();
  document.getElementById('checkoutOffer').value = checkoutOfferCode;
  document.getElementById('offerMsg').innerHTML = '';
  document.getElementById('paymentMsg').innerHTML = '';
  document.getElementById('splitEnabled').checked = false;
  document.getElementById('splitDetail').classList.remove('show');
  document.getElementById('splitPeople').value = 2;
}

function updateCheckoutTotals(){
  const subtotal = checkoutSubtotal();
  const discount = Math.min(checkoutDiscount, subtotal);
  const total = Math.max(0, subtotal - discount);
  document.getElementById('checkoutDiscount').textContent = '-₹'+discount;
  document.getElementById('checkoutTotal').textContent = '₹'+total;
  return total;
}

function applyCheckoutOffer(){
  if(!checkoutCart.length) return;
  const code = document.getElementById('checkoutOffer').value.trim().toUpperCase();
  const price = checkoutSubtotal();
  let discount = 0;
  let message = '';
  if(code === 'WELCOME20') { discount = Math.round(price * .20); message = '20% welcome discount applied.'; }
  else if(code === 'WEEKEND15') { discount = Math.round(price * .15); message = '15% weekend discount applied.'; }
  else if(code === 'STUDENT10' && price >= 250) { discount = Math.round(price * .10); message = '10% student discount applied.'; }
  else if(code === 'BREW100' && price >= 500) { discount = 100; message = '₹100 discount applied.'; }
  else if(code === 'ROAST2X') { discount = 0; message = '2× loyalty points will be awarded on this demo order.'; }
  else if(code === 'MORNING') { discount = 0; message = 'Morning pastry offer noted — pastry bonus is simulated in this demo.'; }
  else { checkoutDiscount = 0; checkoutOfferCode = ''; document.getElementById('offerMsg').innerHTML = '<div class="msg msg-error">Invalid code or minimum order not reached.</div>'; updateCheckoutTotals(); return; }

  checkoutDiscount = discount;
  checkoutOfferCode = code;
  document.getElementById('offerMsg').innerHTML = '<div class="msg msg-ok">'+message+'</div>';
  updateCheckoutTotals();
}

/* ---------- payment + split bill ---------- */
function generateUniquePaymentId(){
  return 'PAY-'+Date.now().toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,7).toUpperCase();
}
function generateSplitCode(){
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'SPLIT-';
  for(let i=0;i<5;i++) code += chars[Math.floor(Math.random()*chars.length)];
  return code;
}
function toggleSplit(){
  const on = document.getElementById('splitEnabled').checked;
  document.getElementById('splitDetail').classList.toggle('show', on);
  if(on) renderSplitMembers();
  else document.getElementById('splitMembers').innerHTML='';
}
function renderSplitMembers(){
  const box=document.getElementById('splitMembers');
  if(!box) return;
  const on=document.getElementById('splitEnabled').checked;
  if(!on){box.innerHTML='';return;}
  const people=Math.min(12,Math.max(2,parseInt(document.getElementById('splitPeople').value)||2));
  document.getElementById('splitPeople').value=people;
  box.innerHTML=Array.from({length:people},(_,i)=>`
    <div class="split-member">
      <h4>Member ${i+1}</h4>
      <div class="field"><label>Name</label><input type="text" id="splitName${i}" placeholder="Member name" autocomplete="name"></div>
      <div class="field" style="margin-bottom:0"><label>Phone number</label><input type="tel" id="splitPhone${i}" placeholder="Numbers only" inputmode="numeric" pattern="[0-9]*" maxlength="15" oninput="this.value=this.value.replace(/\D/g,'')"></div>
    </div>`).join('');
  updateSplitPreview();
}
function getSplitMembers(){
  const people=Math.min(12,Math.max(2,parseInt(document.getElementById('splitPeople').value)||2));
  const members=[];
  for(let i=0;i<people;i++){
    const name=(document.getElementById('splitName'+i)?.value||'').trim();
    const phone=(document.getElementById('splitPhone'+i)?.value||'').trim();
    members.push({name,phone});
  }
  return members;
}
function updateSplitPreview(){
  const box=document.getElementById('splitPreview');
  if(!box) return;
  if(!document.getElementById('splitEnabled').checked){box.innerHTML='';return;}
  const members=getSplitMembers();
  const total=updateCheckoutTotalsNoSplit();
  const per=Math.floor((total*100)/members.length)/100;
  box.innerHTML=`Each member will receive a unique QR. Approximate share: <strong>₹${per.toFixed(2)}</strong> per person.`;
}
function updateCheckoutTotalsNoSplit(){
  const subtotal=checkoutSubtotal();
  const discount=Math.min(checkoutDiscount,subtotal);
  return Math.max(0,subtotal-discount);
}
function renderPaymentPage(){
  if(!checkoutCart.length){go('menu');return;}
  const subtotal=checkoutSubtotal();
  const discount=Math.min(checkoutDiscount,subtotal);
  const total=Math.max(0,subtotal-discount);
  document.getElementById('paymentOrderLines').innerHTML=checkoutCart.map(i=>`<div class="summary-row"><span>${i.name}${i.qty>1?' × '+i.qty:''}</span><strong>₹${i.price*i.qty}</strong></div>`).join('');
  document.getElementById('paymentPrice').textContent='₹'+subtotal;
  document.getElementById('paymentDiscount').textContent='-₹'+discount;
  document.getElementById('paymentTotal').textContent='₹'+total;
  document.getElementById('paymentMsg').innerHTML='';
  document.getElementById('paymentQrResult').innerHTML='';
  document.getElementById('splitEnabled').checked=false;
  document.getElementById('splitDetail').classList.remove('show');
  document.getElementById('splitPeople').value=2;
  document.getElementById('splitMembers').innerHTML='';
}
function buildQr(targetId,text,size=150){
  const el=document.getElementById(targetId);
  if(!el || typeof QRCode==='undefined') return;
  el.innerHTML='';
  new QRCode(el,{text,width:size,height:size,correctLevel:QRCode.CorrectLevel.M});
}
async function shareQr(targetId,title,text){
  const box=document.getElementById(targetId);
  const canvas=box?.querySelector('canvas');
  if(navigator.share && canvas && canvas.toBlob){
    canvas.toBlob(async blob=>{
      try{
        const file=new File([blob],'ember-oak-qr.png',{type:'image/png'});
        if(!navigator.canShare || navigator.canShare({files:[file]})) await navigator.share({title, text, files:[file]});
        else await navigator.share({title,text});
      }catch(e){}
    });
  }else{
    const img=box?.querySelector('img');
    if(img?.src){const a=document.createElement('a');a.href=img.src;a.download='ember-oak-qr.png';a.click();}
  }
}
function downloadQr(targetId){
  const box=document.getElementById(targetId);
  const canvas=box?.querySelector('canvas');
  const img=box?.querySelector('img');
  const src=canvas?.toDataURL('image/png') || img?.src;
  if(src){const a=document.createElement('a');a.href=src;a.download='ember-oak-qr.png';a.click();}
}
function completePayment(){
  const c=currentCustomer();
  if(!c || !checkoutCart.length){go('login');return;}
  const payment=document.querySelector('input[name="payment"]:checked')?.value||'UPI';
  const total=updateCheckoutTotalsNoSplit();
  const splitOn=document.getElementById('splitEnabled').checked;
  let members=[];
  if(splitOn){
    members=getSplitMembers();
    if(members.some(m=>!m.name || !/^\d+$/.test(m.phone))){
      document.getElementById('paymentMsg').innerHTML='<div class="msg msg-error">Please enter every member name and a phone number using numbers only.</div>';
      return;
    }
  }

  const paymentId=generateUniquePaymentId();
  const splitCode=splitOn?generateSplitCode():null;
  const splitPeople=splitOn?members.length:null;
  const itemSummary=checkoutCart.map(i=>i.name+(i.qty>1?' ×'+i.qty:'')).join(', ');
  const order={id:orderSeq++,paymentId,customerId:c.id,customerName:c.name,item:itemSummary,price:total,status:'Ordering',payment,splitCode,splitPeople};
  orders.push(order); c.orders.push(order);

  let points=Math.round(total/10); if(checkoutOfferCode==='ROAST2X') points*=2; c.points+=points;
  saveOrders(); saveCustomers();
  if(checkoutSource==='cart'){cart=[];saveCart();renderCartBadge();}

  const baseCents=Math.floor((total*100)/Math.max(1,splitPeople||1));
  const remainder=Math.round(total*100)-baseCents*Math.max(1,splitPeople||1);
  const qrMembers=members.map((m,i)=>({...m,amount:((baseCents+(i<remainder?1:0))/100).toFixed(2),code:splitCode}));

  const result=document.getElementById('paymentQrResult');
  result.innerHTML='';

  // UPI and QR both generate the bill AND the payment QR.
  // Card, Net Banking, Wallet and Cash generate the bill only.
  const showPaymentQr = payment==='UPI' || payment==='QR';

  // Build the bill first so it is always present.
  let billRows=checkoutCart.map(i=>`<tr><td>${i.name}</td><td>${i.qty}</td><td>₹${(i.price*i.qty).toFixed(2)}</td></tr>`).join('');
  let splitRows=splitOn ? qrMembers.map(m=>`<tr><td>${m.name}</td><td>${m.phone}</td><td>₹${m.amount}</td></tr>`).join('') : '';

  let billHtml=`<div class="card payment-bill">
    <div style="display:flex;justify-content:space-between;gap:15px;align-items:start;">
      <div><span class="eyebrow">Payment receipt</span><h3 style="margin:4px 0;">Ember &amp; Oak Café</h3><div>${paymentId}</div></div>
      <div style="font-size:1.5rem;">🧾</div>
    </div>
    <hr>
    <table style="width:100%;margin:12px 0;"><thead><tr><th style="text-align:left;">Item</th><th>Qty</th><th style="text-align:right;">Amount</th></tr></thead><tbody>${billRows}</tbody></table>
    <div class="summary-row"><span>Payment method</span><strong>${payment}</strong></div>
    <div class="summary-row summary-total"><span>Total paid</span><strong>₹${total}</strong></div>
    ${splitOn?`<hr><h4>Split bill</h4><table style="width:100%;"><thead><tr><th style="text-align:left;">Member</th><th>Phone</th><th>Share</th></tr></thead><tbody>${splitRows}</tbody></table>`:''}
    <p style="margin-top:14px;text-align:center;">Thank you for choosing Ember &amp; Oak ☕</p>
    <button class="btn btn-ghost btn-sm" onclick="window.print()">Print Bill</button>
  </div>`;

  let qrHtml='';
  if(showPaymentQr){
    const orderQrText=JSON.stringify({
      merchant:'Ember & Oak',paymentId,amount:total,currency:'INR',
      paymentMethod:payment,
      order:checkoutCart.map(i=>({name:i.name,qty:i.qty,price:i.price}))
    });

    qrHtml=`<div class="card qr-card">
      <div class="qr-box" id="orderQr"></div>
      <div class="qr-info">
        <span class="eyebrow">${payment==='UPI'?'UPI payment QR':'Unique order QR'}</span>
        <h3 style="margin-bottom:6px;">${paymentId}</h3>
        <p>Scan this QR to pay <strong>₹${total}</strong> via ${payment==='UPI'?'UPI':'QR'}.</p>
        <button class="btn btn-ghost btn-sm" onclick="shareQr('orderQr','Ember & Oak payment QR','Payment ${paymentId} · ₹${total}')">Share QR</button>
        <button class="btn btn-ghost btn-sm" onclick="downloadQr('orderQr')">Download QR</button>
      </div>
    </div>`;

    if(splitOn){
      qrHtml+=`<div class="split-result"><h3>Split payment QR codes</h3><p>Each member has a separate QR for their exact share. Split code: <span class="booking-code">${splitCode}</span></p>`;
      qrMembers.forEach((m,i)=>{
        const id='splitQr'+i;
        qrHtml+=`<div class="qr-card"><div class="qr-box" id="${id}"></div><div class="qr-info"><strong>${m.name}</strong><p style="margin:4px 0;">Phone: ${m.phone}<br>Share: <strong>₹${m.amount}</strong></p><button class="btn btn-ghost btn-sm" onclick="shareQr('${id}','Ember & Oak split bill','${m.name} · ₹${m.amount} · ${paymentId}')">Send QR</button> <button class="btn btn-ghost btn-sm" onclick="downloadQr('${id}')">Download</button></div></div>`;
      });
      qrHtml+='</div>';
    }

    result.innerHTML=qrHtml + billHtml;
    buildQr('orderQr',orderQrText,150);
    qrMembers.forEach((m,i)=>buildQr('splitQr'+i,JSON.stringify({
      merchant:'Ember & Oak',paymentId,splitCode,member:m.name,phone:m.phone,amount:m.amount,currency:'INR',paymentMethod:payment
    }),150));
  } else {
    result.innerHTML=billHtml;
  }

  document.getElementById('paymentMsg').innerHTML=`<div class="success-box">
    <h3>${payment==='QR'?'QR payment ready!':'Bill generated!'} ☕🎉</h3>
    <p><strong>${itemSummary}</strong> is now placed.</p>
    <p><strong>Payment:</strong> ${payment} · <strong>Total:</strong> ₹${total} · <strong>Points:</strong> +${points}</p>
    <button class="btn btn-primary" onclick="go('customer')">Continue</button>
  </div>`;
  funBurst();
}

/* ============================================================
   DRINK BUILDER
   ============================================================ */
function renderBuilder(){
  const groups = [
    ['builderBase', DRINK_BASES, 'base'],
    ['builderMilk', DRINK_MILKS, 'milk'],
    ['builderSize', DRINK_SIZES, 'size'],
    ['builderSyrup', DRINK_SYRUPS, 'syrup']
  ];

  const isGreenTea = builderChoice.base === 'greentea';

  groups.forEach(([elId, list, key])=>{
    document.getElementById(elId).innerHTML = list.map(o=>`
      <button class="option-chip ${builderChoice[key]===o.id?'active':''}" onclick="setBuilderChoice('${key}','${o.id}')">
        ${o.name} ${o.price>0 ? `<small>+₹${o.price}</small>` : ''}
      </button>`).join('');
  });

  document.getElementById('builderExtra').innerHTML = DRINK_EXTRAS.map(o=>`
    <button class="option-chip ${builderChoice.extras.includes(o.id)?'active':''}" onclick="toggleBuilderExtra('${o.id}')">
      ${o.name} <small>+₹${o.price}</small>
    </button>`).join('');

  // Green Tea does not allow milk, syrup or extras.
  ['builderMilk','builderSyrup','builderExtra'].forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    const group = el.closest('.option-group');
    if(group) group.classList.toggle('builder-disabled', isGreenTea);
  });

  renderBuilderPreview();
  updateCartoonBuilder();
}
function setBuilderChoice(key,id){
  builderChoice[key]=id;

  // Green Tea is served without milk, syrup or extras.
  if(key==='base' && id==='greentea'){
    builderChoice.milk='none';
    builderChoice.syrup='none';
    builderChoice.extras=[];
  }

  renderBuilder();

  const lists={base:DRINK_BASES,milk:DRINK_MILKS,size:DRINK_SIZES,syrup:DRINK_SYRUPS};
  const item=lists[key]?.find(o=>o.id===id);
  if(item && !(key==='milk'&&id==='none') && !(key==='syrup'&&id==='none')){
    showIngredientAnimation(item.name,{base:'☕',milk:'🥛',size:'📏',syrup:'🍯'}[key]);
  }
}
function toggleBuilderExtra(id){
  if(builderChoice.base==='greentea') return;
  const r=builderChoice.extras.includes(id);
  if(r)builderChoice.extras=builderChoice.extras.filter(x=>x!==id);
  else builderChoice.extras.push(id);
  renderBuilder();
  const item=DRINK_EXTRAS.find(o=>o.id===id);
  if(item&&!r)showIngredientAnimation(item.name,id==='cream'?'🍦':'⚡');
}
function builderPriceAndSummary(){
  const base = DRINK_BASES.find(o=>o.id===builderChoice.base);
  const milk = DRINK_MILKS.find(o=>o.id===builderChoice.milk);
  const size = DRINK_SIZES.find(o=>o.id===builderChoice.size);
  const syrup = DRINK_SYRUPS.find(o=>o.id===builderChoice.syrup);
  const extras = DRINK_EXTRAS.filter(o=>builderChoice.extras.includes(o.id));
  const BASE_PRICE = 130;
  let price = BASE_PRICE + base.price + milk.price + size.price + syrup.price;
  extras.forEach(e=>price += e.price);
  const parts = [size.name+' '+base.name, milk.id!=='none' ? milk.name : null, syrup.id!=='none' ? syrup.name+' syrup' : null, ...extras.map(e=>e.name)].filter(Boolean);
  const name = size.name+' '+base.name+(syrup.id!=='none' ? ' — '+syrup.name : '');
  return {price, parts, name};
}
function updateCoffeeBuilderVideo(){
  const video = document.getElementById('coffeeBuilderVideo');
  const caption = document.getElementById('coffeeVideoCaption');
  if(!video) return;
  const segments = {espresso:[0,2], coldbrew:[2,4], greentea:[4,6], hotchoc:[6,8]};
  const [start,end] = segments[builderChoice.base] || segments.espresso;
  const base = DRINK_BASES.find(o=>o.id===builderChoice.base);
  const milk = DRINK_MILKS.find(o=>o.id===builderChoice.milk);
  const syrup = DRINK_SYRUPS.find(o=>o.id===builderChoice.syrup);
  const extras = DRINK_EXTRAS.filter(o=>builderChoice.extras.includes(o.id)).map(o=>o.name);
  const details = [base?.name, milk?.id!=='none' ? milk?.name : null, syrup?.id!=='none' ? syrup?.name : null, ...extras].filter(Boolean).join(' • ');
  if(caption) caption.textContent = '☕ Crafting: ' + details;
  video.loop = false;
  const seekAndPlay = ()=>{
    try{
      video.currentTime = start + 0.05;
      video.play().catch(()=>{});
    }catch(e){}
  };
  if(video.readyState >= 1) seekAndPlay();
  else video.addEventListener('loadedmetadata', seekAndPlay, {once:true});
  video.ontimeupdate = ()=>{
    if(video.currentTime >= end){
      video.currentTime = start + 0.05;
      video.play().catch(()=>{});
    }
  };
}

function updateCartoonBuilder(){
  const base=DRINK_BASES.find(o=>o.id===builderChoice.base), milk=DRINK_MILKS.find(o=>o.id===builderChoice.milk), syrup=DRINK_SYRUPS.find(o=>o.id===builderChoice.syrup), size=DRINK_SIZES.find(o=>o.id===builderChoice.size);
  const extras=DRINK_EXTRAS.filter(o=>builderChoice.extras.includes(o.id));
  const colors={espresso:['#5b2d1c','#32170f'],coldbrew:['#3f2117','#24110c'],greentea:['#718451','#43542d'],hotchoc:['#6d3a24','#3a1b10']};
  const c=colors[builderChoice.base]||colors.espresso, top=document.getElementById('cupTopLiquid'), bottom=document.getElementById('cupLiquid');
  if(!top||!bottom)return;
  top.setAttribute('fill',c[0]); bottom.setAttribute('fill',c[0]);
  const grad=document.getElementById('liquidGrad'); if(grad){grad.children[0].setAttribute('stop-color',c[0]);grad.children[1].setAttribute('stop-color',c[1]);}
  document.getElementById('milkLayer').classList.toggle('show',milk&&milk.id!=='none');
  document.getElementById('syrupLayer').classList.toggle('show',syrup&&syrup.id!=='none');
  document.getElementById('shotLayer').classList.toggle('show',builderChoice.extras.includes('shot'));
  document.getElementById('creamLayer').classList.toggle('show',builderChoice.extras.includes('cream'));
  const labels=['🥤 '+(size?.name||'Regular'),'☕ '+(base?.name||'Espresso')];
  if(milk&&milk.id!=='none')labels.push('🥛 '+milk.name);
  if(syrup&&syrup.id!=='none')labels.push('🍯 '+syrup.name);
  extras.forEach(e=>labels.push(e.id==='shot'?'⚡ Extra shot':'🍦 Whipped cream'));
  document.getElementById('builderIngredientBadges').innerHTML=labels.map(x=>`<span>${x}</span>`).join('');
}

function renderBuilderPreview(){const {price,parts,name}=builderPriceAndSummary();document.getElementById('builderName').textContent=name;document.getElementById('builderSummary').innerHTML=parts.map(p=>`<li>${p}</li>`).join('');document.getElementById('builderPrice').textContent='₹'+price;updateVisualDrink();}
function updateVisualDrink(){const b=DRINK_BASES.find(o=>o.id===builderChoice.base),m=DRINK_MILKS.find(o=>o.id===builderChoice.milk),s=DRINK_SYRUPS.find(o=>o.id===builderChoice.syrup);const l=document.getElementById('drinkLiquid'),ml=document.getElementById('drinkMilkLayer'),sl=document.getElementById('drinkSyrupLayer'),t=document.getElementById('drinkTopping'),p=document.getElementById('pickedIngredients');if(!l)return;l.style.background={espresso:'#704027',coldbrew:'#3a241c',greentea:'#8da65a',hotchoc:'#5a2c20'}[builderChoice.base];ml.style.opacity=m.id==='none'?0:1;sl.style.opacity=s.id==='none'?0:1;t.style.opacity=builderChoice.extras.includes('cream')?1:0;t.style.height=builderChoice.extras.includes('cream')?'35px':'0';p.innerHTML=[['☕',b.name],m.id!=='none'?['🥛',m.name]:null,s.id!=='none'?['🍯',s.name+' syrup']:null,...DRINK_EXTRAS.filter(o=>builderChoice.extras.includes(o.id)).map(o=>[o.id==='cream'?'🍦':'⚡',o.name])].filter(Boolean).map(x=>`<span class="picked-ingredient">${x[0]} ${x[1]}</span>`).join('');}
function showIngredientAnimation(text,icon){const a=document.getElementById('ingredientAnimation'),st=document.getElementById('buildingStatus');if(!a)return;const e=document.createElement('div');e.className='flying-ingredient';e.textContent=icon+' '+text;a.appendChild(e);st.textContent='✨ Adding '+text+' to your drink…';setTimeout(()=>st.textContent='✓ '+text+' added!',650);setTimeout(()=>e.remove(),850);}
function addBuilderToCart(){
  const c = currentCustomer();
  if(!c){ document.getElementById('builderMsg').innerHTML = '<div class="msg msg-error">Please sign in to add items to your cart.</div>'; return; }
  const {price, name} = builderPriceAndSummary();
  cart.push({key:'custom-'+Date.now(), name:'Custom: '+name, price:price, qty:1, cat:'Custom', img:null});
  saveCart();
  renderCartBadge();
  document.getElementById('builderMsg').innerHTML = '<div class="msg msg-ok">Added to cart! 🎉 <a href="#" onclick="go(\'cart\');return false;" style="color:var(--olive);">View cart →</a></div>';
  funBurst();
}

/* ============================================================
   TABLES
   ============================================================ */
function renderTables(){
  document.getElementById('tableSizeGrid').innerHTML = TABLE_SIZES.map(size=>`
    <div class="table-option ${selectedTableSize===size?'active':''}" onclick="selectTableSize(${size})">
      <div class="seat-icon">🪑</div>
      <div class="seat-count">${size}</div>
      <div class="seat-label">Seats</div>
    </div>`).join('');
  const c = currentCustomer();
  if(c && !document.getElementById('tblName').value) document.getElementById('tblName').value = c.name;
  document.getElementById('tableMsg').innerHTML = '';
}
function selectTableSize(size){
  selectedTableSize = size;
  renderTables();
}
function reserveTable(){
  const msg = document.getElementById('tableMsg');
  const name = document.getElementById('tblName').value.trim();
  const phone = document.getElementById('tblPhone').value.trim();
  const date = document.getElementById('tblDate').value;
  const time = document.getElementById('tblTime').value;
  if(!selectedTableSize){ msg.innerHTML = '<div class="msg msg-error">Please choose a table size.</div>'; return; }
  if(!name || !date || !time){ msg.innerHTML = '<div class="msg msg-error">Please fill in your name, date and time.</div>'; return; }
  const c = currentCustomer();
  const code = 'TBL-' + Math.random().toString(36).slice(2,7).toUpperCase();
  const booking = {id:Date.now(), customerId:c?c.id:null, name, phone, size:selectedTableSize, date, time, code, status:'Confirmed'};
  tableBookings.push(booking);
  saveTableBookings();
  msg.innerHTML = `<div class="success-box"><h3>Table reserved! 🪑🎉</h3><p>Table for <strong>${selectedTableSize}</strong> on <strong>${date}</strong> at <strong>${time}</strong>.</p><p>Booking code: <span class="booking-code">${code}</span></p></div>`;
  funBurst();
  selectedTableSize = null;
}

/* ============================================================
   LOYALTY / ROAST GAUGE
   ============================================================ */
const TIERS = [
  {name:'Green Bean', min:0},
  {name:'Light Roast', min:50},
  {name:'Medium Roast', min:150},
  {name:'Dark Roast', min:300},
  {name:'Espresso Master', min:500}
];
function tierFor(points){
  let t = TIERS[0];
  for(const tier of TIERS){ if(points>=tier.min) t=tier; }
  return t;
}
function gaugePercent(points){
  const capped = Math.min(points, 500);
  return (capped/500)*100;
}

/* ============================================================
   CUSTOMER DASHBOARD
   ============================================================ */
function currentCustomer(){ return customers.find(c=>c.id===session.customerId); }

function renderCustomerDash(){
  const c = currentCustomer();
  if(!c){ go('login'); return; }
  document.getElementById('custName').textContent = c.name;
  document.getElementById('custPoints').textContent = c.points;
  const tier = tierFor(c.points);
  document.getElementById('custTier').textContent = tier.name;
  document.getElementById('gaugeMarker').style.left = gaugePercent(c.points)+'%';

  const sel = document.getElementById('quickOrderItem');
  sel.innerHTML = menu.map(m=>`<option value="${m.id}">${m.name} — ₹${m.price}</option>`).join('');

  const myOrders = orders.filter(o=>o.customerId===c.id);
  document.getElementById('custOrderBoard').innerHTML = myOrders.length ? myOrders.map(o=>`
    <div class="kanban-item">
      <div class="who">${o.item}</div>
      <span class="status-pill status-${o.status}">${STATUS_LABEL[o.status]}</span>
    </div>`).join('') : '<p class="empty">No active orders. Place one above!</p>';

  document.getElementById('custHistoryBody').innerHTML = myOrders.length ? myOrders.map(o=>`
    <tr><td>${o.item}</td><td><span class="status-pill status-${o.status}">${STATUS_LABEL[o.status]}</span></td><td>+${Math.round(o.price/10)}</td></tr>
  `).join('') : '<tr><td colspan="3" class="empty">No orders yet.</td></tr>';

  renderMoodRow();
  renderAiChatlog();
}

function placeQuickOrder(){
  const c = currentCustomer();
  const id = parseInt(document.getElementById('quickOrderItem').value);
  const item = menu.find(m=>m.id===id);
  if(!item) return;
  const order = {id:orderSeq++, customerId:c.id, customerName:c.name, item:item.name, price:item.price, status:'Ordering'};
  orders.push(order);
  c.orders.push(order);
  c.points += Math.round(item.price/10);
  saveOrders();
  saveCustomers();
  document.getElementById('orderMsg').innerHTML = `<div class="msg msg-ok">Order placed! Watch the board below for status updates.</div>`;
  renderCustomerDash();
}

/* ============================================================
   AI BARISTA (real Claude API call)
   ============================================================ */
const MOODS = ['Sleepy','Cozy','Energetic','Adventurous','Stressed','Sweet tooth'];
function renderMoodRow(){
  document.getElementById('moodRow').innerHTML = MOODS.map(m=>
    `<button class="mood-btn ${currentMood===m?'active':''}" onclick="pickMood('${m}')">${m}</button>`
  ).join('');
}
function pickMood(m){
  currentMood = m;
  renderMoodRow();
  askBarista(`I'm feeling ${m.toLowerCase()} today. What should I order?`);
}

const DEFAULT_BARISTA_MESSAGE = "Hey there! ☕ I'm your Ember & Oak Barista. Tell me your mood, caffeine level, sweetness craving, or what you're eating, and I'll help you pick something from today's menu — and I'll actually remember what we talked about!";
const STARTER_CHIPS = ["I need caffeine, fast ⚡", "Something sweet 🍯", "I'm feeling adventurous 🌶️", "Surprise me ☕"];
let chatHistory = []; // {role:'user'|'bot', text}

function greetingForBarista(){
  const c = currentCustomer();
  const name = c && c.name ? c.name.split(' ')[0] : null;
  const moodBit = currentMood ? ` I see you're feeling ${currentMood.toLowerCase()} — noted.` : '';
  return name
    ? `Hey ${name}! ☕ Good to see you again.${moodBit} What are you craving today?`
    : DEFAULT_BARISTA_MESSAGE;
}

function renderAiChatlog(){
  const log = document.getElementById('aiChatlog');
  log.innerHTML = chatHistory.map(m=>`<div class="ai-msg ${m.role==='user'?'user':'bot'}">${m.text}</div>`).join('')
    || '<div class="ai-msg bot">'+greetingForBarista()+'</div>';
  log.scrollTop = log.scrollHeight;
  renderAiSuggestChips();
}

function renderAiSuggestChips(){
  const row = document.getElementById('aiSuggestRow');
  if(!row) return;
  // Before any conversation, show fun starter prompts. After a reply, offer natural follow-ups.
  const chips = chatHistory.length === 0
    ? STARTER_CHIPS
    : ["Tell me more", "Got something cheaper?", "What pairs well with it?", "New mood, new pick"];
  row.innerHTML = chips.map(c=>`<button type="button" class="ai-chip" onclick="askBarista('${c.replace(/'/g,"\\'")}')">${c}</button>`).join('');
}

function resetBaristaChat(){
  chatHistory = [];
  currentMood = null;
  renderMoodRow();
  renderAiChatlog();
}

function sendToBarista(){
  const input = document.getElementById('aiInput');
  const text = input.value.trim();
  if(!text) return;
  input.value = '';
  askBarista(text);
}

async function askBarista(userText){
  chatHistory.push({role:'user', text:userText});
  renderAiChatlog();
  const log = document.getElementById('aiChatlog');
  const typingEl = document.createElement('div');
  typingEl.className = 'typing';
  typingEl.innerHTML = 'The barista is thinking <span class="typing-dots"><span></span><span></span><span></span></span>';
  log.appendChild(typingEl);
  log.scrollTop = log.scrollHeight;

  const menuText = menu.map(m=>`- ${m.name} (${m.cat}, ₹${m.price}): ${m.desc}`).join('\n');
  const c = currentCustomer();
  const nameBit = c && c.name ? `The customer's name is ${c.name.split(' ')[0]} — you can use it occasionally.` : '';
  const moodBit = currentMood ? `They picked the mood "${currentMood}" from the mood picker.` : '';
  const systemPrompt = `You are the friendly, upbeat, slightly witty AI barista at "Ember & Oak", a small roastery cafe. Only recommend items that appear on the menu below — never invent items. Keep replies short (2-4 sentences), warm, and specific about WHY the pick fits what the customer said. Stay in character as a real barista having a genuine back-and-forth conversation — refer back to things they've told you earlier in the chat when relevant, ask a light follow-up question sometimes, and feel free to use a little playful humor or a relevant emoji. ${nameBit} ${moodBit} Today's menu:\n${menuText}`;

  // Send the full conversation so far so the barista actually remembers the chat.
  const apiMessages = chatHistory.map(m => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }));

  try{
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: systemPrompt,
        messages: apiMessages
      })
    });
    const data = await response.json();
    const textBlock = (data.content || []).find(b=>b.type==='text');
    const reply = textBlock ? textBlock.text : "Sorry, I couldn't come up with a recommendation just now — try the Oak-Smoked Cold Brew, it's rarely wrong.";
    typingEl.remove();
    chatHistory.push({role:'bot', text: reply});
  } catch(err){
    typingEl.remove();
    // graceful fallback so the demo still feels alive offline
    const fallback = ruleBasedFallback(userText);
    chatHistory.push({role:'bot', text: fallback});
  }
  renderAiChatlog();
}

function ruleBasedFallback(text){
  const t = text.toLowerCase();
  if(t.includes('sleep')||t.includes('tired')) return "Sounds like you need the Dark Roast Espresso — a double shot to get you moving.";
  if(t.includes('cozy')||t.includes('cold')) return "Go with the Hojicha Latte — roasted, smoky-sweet, and warm in your hands.";
  if(t.includes('sweet')) return "The Cardamom Sticky Bun paired with a Cortado hits that sweet spot.";
  if(t.includes('adventur')) return "Try the Oak-Smoked Cold Brew — it's our most unusual pour, smoked over oak chips.";
  return "I'd suggest the Single-Origin Pour Over — bright, floral, and a good all-rounder any time of day.";
}

/* ============================================================
   ADMIN DASHBOARD
   ============================================================ */
function setAdminTab(tab){
  adminTab = tab;
  document.querySelectorAll('.tabbar button').forEach(b=>b.classList.remove('active'));
  event.target.classList.add('active');
  document.querySelectorAll('.admin-panel').forEach(p=>p.classList.remove('active'));
  document.getElementById('admin-'+tab).classList.add('active');
}

function renderAdminDash(){
  document.getElementById('statCustomers').textContent = customers.length;
  document.getElementById('statOrders').textContent = orders.length;
  document.getElementById('statRevenue').textContent = '₹'+orders.reduce((s,o)=>s+o.price,0);
  document.getElementById('statMenu').textContent = menu.length;
  renderKanban();
  renderMenuAdmin();
  renderCustomersAdmin();
  renderTablesAdmin();
}

function renderTablesAdmin(){
  const body = document.getElementById('tablesAdminBody');
  if(!body) return;
  body.innerHTML = tableBookings.length ? tableBookings.map(b=>`
    <tr><td>${b.code}</td><td>${b.name}</td><td>${b.size}</td><td>${b.date}</td><td>${b.time}</td><td>${b.phone||'—'}</td></tr>
  `).join('') : '<tr><td colspan="6" class="empty">No table reservations yet.</td></tr>';
}

function renderKanban(){
  const board = document.getElementById('kanbanBoard');
  board.innerHTML = STATUS_FLOW.map(status=>{
    const items = orders.filter(o=>o.status===status);
    return `<div class="kanban-col">
      <h4>${STATUS_LABEL[status]} (${items.length})</h4>
      ${items.map(o=>`
        <div class="kanban-item">
          <div class="who">${o.customerName}</div>
          <div>${o.item} · ₹${o.price}</div>
          ${status!=='Picked' ? `<button class="btn btn-ghost btn-sm" onclick="advanceOrder(${o.id})">Move to ${STATUS_LABEL[STATUS_FLOW[STATUS_FLOW.indexOf(status)+1]]} →</button>` : ''}
        </div>`).join('') || '<p class="empty" style="font-size:.78rem;">Empty</p>'}
    </div>`;
  }).join('');
}
function advanceOrder(id){
  const o = orders.find(x=>x.id===id);
  const idx = STATUS_FLOW.indexOf(o.status);
  if(idx < STATUS_FLOW.length-1) o.status = STATUS_FLOW[idx+1];
  saveOrders();
  renderAdminDash();
}

function renderMenuAdmin(){
  document.getElementById('menuAdminBody').innerHTML = menu.map(m=>`
    <tr>
      <td>${m.name}</td><td>${m.cat}</td><td>₹${m.price}</td>
      <td><button class="icon-btn" onclick="removeMenuItem(${m.id})">Remove</button></td>
    </tr>`).join('');
}
function addMenuItem(){
  const name = document.getElementById('mNewName').value.trim();
  const cat = document.getElementById('mNewCat').value;
  const price = parseInt(document.getElementById('mNewPrice').value) || 0;
  const img = document.getElementById('mNewImg').value.trim() || `https://loremflickr.com/400/300/${encodeURIComponent((name||'coffee').split(' ').slice(0,2).join(','))}/all?lock=${Date.now()%1000}`;
  const desc = document.getElementById('mNewDesc').value.trim() || 'A new addition to the board.';
  if(!name || !price){ alert('Please enter a name and price.'); return; }
  menu.push({id:Date.now(), name, cat, price, desc, img});
  saveMenu();
  ['mNewName','mNewPrice','mNewImg','mNewDesc'].forEach(id=>document.getElementById(id).value='');
  renderAdminDash();
}
function removeMenuItem(id){
  menu = menu.filter(m=>m.id!==id);
  saveMenu();
  renderAdminDash();
}

function renderCustomersAdmin(){
  document.getElementById('customersAdminBody').innerHTML = customers.map(c=>`
    <tr>
      <td>${c.name}</td><td>${c.email}</td><td>${c.points}</td>
      <td>${tierFor(c.points).name}</td>
      <td>${orders.filter(o=>o.customerId===c.id).length}</td>
    </tr>`).join('');
}

/* ============================================================
   INIT
   ============================================================ */
initApp();
document.getElementById('loginId')?.addEventListener('input',e=>sanitizeLoginId(e.target));
document.getElementById('suUsername')?.addEventListener('input',e=>sanitizeLoginId(e.target));
document.addEventListener('keydown',e=>{ if(e.key==='Enter' && document.activeElement?.id==='aiInput'){ e.preventDefault(); sendToBarista(); } });



function pickLoginMood(btn, mood){
  document.querySelectorAll('.mood-pill').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const messages={
    cozy:'Cozy mode activated — something warm and comforting is calling your name.',
    energetic:'Energy mode activated — let’s get you a bold brew and a little boost! ⚡',
    sweet:'Sweet mode activated — time for a creamy, dessert-like coffee moment. 🍯',
    chill:'Chill mode activated — slow sips, soft vibes, zero rush. 🌿'
  };
  const el=document.getElementById('loginMoodText');
  if(el){
    el.textContent=messages[mood]||messages.cozy;
    el.animate([{opacity:.25,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:280,easing:'ease-out'});
  }
  try{localStorage.setItem('emberLoginMood',mood);}catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>{
  try{
    const saved=localStorage.getItem('emberLoginMood');
    if(saved){
      const btn=[...document.querySelectorAll('.mood-pill')].find(b=>b.getAttribute('onclick')?.includes("'"+saved+"'"));
      if(btn) pickLoginMood(btn,saved);
    }
  }catch(e){}
});



(function(){
  function setupBookingPhones(){
    const view = document.getElementById('view-tables') || document;
    const fields = view.querySelectorAll(
      'input[type="tel"], input[name*="phone" i], input[id*="phone" i], input[name*="mobile" i], input[id*="mobile" i]'
    );
    fields.forEach(function(input){
      input.type='tel';
      input.inputMode='numeric';
      input.minLength=10;
      input.maxLength=10;
      input.pattern='[0-9]{10}';
      input.required=true;
      input.addEventListener('input', function(){
        this.value=this.value.replace(/[^0-9]/g,'').slice(0,10);
        this.setCustomValidity(
          this.value.length===10 ? '' : 'Phone number must be exactly 10 digits.'
        );
      });
    });
  }

  document.addEventListener('input', function(e){
    if(e.target.matches('input[name*="phone" i],input[id*="phone" i],input[name*="mobile" i],input[id*="mobile" i]')){
      e.target.value=e.target.value.replace(/[^0-9]/g,'').slice(0,10);
      e.target.setCustomValidity(e.target.value.length===10 ? '' : 'Phone number must be exactly 10 digits.');
    }
  });

  document.addEventListener('DOMContentLoaded', setupBookingPhones);
  window.addEventListener('load', setupBookingPhones);
  setTimeout(setupBookingPhones, 300);
})();



(function(){
  function syncPaymentUI(){
    const selected=document.querySelector('input[name="payment"]:checked')?.value||'UPI';
    const btn=document.getElementById('paymentActionBtn');
    if(btn) btn.textContent=selected==='QR'?'Generate QR & Pay':'Generate Bill & Pay';
    const box=document.getElementById('paymentQrResult');
    if(box) box.innerHTML='';
    const msg=document.getElementById('paymentMsg');
    if(msg) msg.innerHTML='';
  }
  document.addEventListener('change',function(e){
    if(e.target.matches('input[name="payment"]')) syncPaymentUI();
  });
  document.addEventListener('DOMContentLoaded',syncPaymentUI);
})();



(function(){
  function isQRSelected(){
    const r=document.querySelector('input[name="payment"]:checked');
    return r && (r.value || '').toLowerCase() === 'qr';
  }

  function updateBillQR(){
    const result=document.getElementById('paymentQrResult');
    const billQR=document.getElementById('billQrCode');
    if(!result || !billQR) return;

    if(isQRSelected()){
      // Keep whatever QR generator the existing payment code creates.
      // If it creates an image/canvas inside paymentQrResult, mirror it into the bill.
      const qr = result.querySelector('canvas, img, svg');
      billQR.innerHTML='';
      if(qr){
        billQR.appendChild(qr.cloneNode(true));
      }else{
        billQR.innerHTML='<div style="font-size:.72rem;color:var(--fg-muted)">Generate payment QR to display it here.</div>';
      }
    }else{
      billQR.innerHTML='';
    }
  }

  document.addEventListener('change',function(e){
    if(e.target.matches('input[name="payment"]')){
      setTimeout(updateBillQR,100);
    }
  });

  const result=document.getElementById('paymentQrResult');
  if(result){
    new MutationObserver(()=>setTimeout(updateBillQR,50)).observe(result,{childList:true,subtree:true});
  }

  document.addEventListener('click',function(e){
    const btn=e.target.closest('button');
    if(btn && /qr|pay|bill|generate/i.test(btn.textContent||'')){
      setTimeout(updateBillQR,250);
    }
  });

  window.addEventListener('load',()=>setTimeout(updateBillQR,300));
})();
